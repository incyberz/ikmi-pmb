<?php 
// penanggalan =============================================
date_default_timezone_set("Asia/Jakarta");
$tanggal_skg = date("Y-m-d");
$tanggaljam_skg = date("Y-m-d H:i:sa");
$jam_skg = date("H:i:sa");
$tahun_skg = date("Y");
$thn_skg = date("y");
// penanggalan =============================================


$link_back = "<a href='javascript:history.go(-1)'>Kembali</a>";
$btn_back = "<a href='javascript:history.go(-1)'><button class='btn btn-primary'>Kembali</button></a>";


?>
