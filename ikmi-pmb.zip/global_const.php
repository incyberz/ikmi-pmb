<?php

define('biaya_daftar', 200000);
define('biaya_daftar_cap', 'Rp 200.000,-');
