<br>
<br>
<section id="lupa_pas" class="about">
  <div class="container" data-aos="fade-up">
    <hr>

    <h5>Lupa Password</h5>
    <p>Jika Anda lupa password silahkan hubungi kami via WhatsApp !</p>

    <div class="row">
    	<div class="col-md-5">
    		<hr>
    		<textarea rows="3" class="form-control">Saya lupa password login, email saya adalah user@gmail.com</textarea>
    		<hr>
    		<button class="btn btn-primary btn-sm" onclick="alert('Feature On project... please be patient!')">Kirim ke WhatsApp IKMI</button> |  
    		<a href="?p=daftar3">Kembali</a>
    		
    	</div>
    	
    </div>


  </div>
</section>








