<section id="brosur" class="pricing">
  <div class="container" data-aos="fade-up">

    <div class="row">
      <div class="col-md-6">
      	<h2>Jalur Transportasi Umum</h2>
      	<hr>
      	<img src="assets/img/jalur.png" class="img-fluid">

        
      </div>
    </div>

  </div>
</section><!-- End Pricing Section -->
