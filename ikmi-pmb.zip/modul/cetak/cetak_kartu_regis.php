<?php 
// session_start(); 
$debug_mode = 0;
// if (!isset($_SESSION['email'])) {die("Error #6asd5321434b234as");}
// if (!isset($_SESSION['nama_calon'])) {die("Error #6d3f345j34k5345");}
// $email = $_SESSION['email'];
// $nama_calon = $_SESSION['nama_calon'];


// include "config.php";
// include "user_var.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>PMB IKMI</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <script type="text/javascript" src="assets/js/jquery.min.js"></script>
  <style type="text/css">
    div{
      border: solid 1px #ddd;
    }
  </style>

</head>

<body>
  <div class="row">
    <div class="col-md-4" style="padding: 5px">
      <div>
        No Pendaftaran: ................
      </div>
    </div>
    <div class="col-md-4" style="padding: 5px">
      <div>
        No Pendaftaran: ................
      </div>
    </div>
    <div class="col-md-4" style="padding: 5px">
      <div>
        No Pendaftaran: ................
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-2">
      <img class="img-fluid" src="assets/img/logos/ikmi120px.png">
    </div>
    <div class="col-md-10">
      <h1>STMIK IKMI CIREBON</h1>
    </div>
    
  </div>

  <div class="row">
    <div class="col-md-12">
      <center>
        <h3>KARTU REGISTRASI ULANG</h3>
      </center>
    </div>
  </div>


  <table class="table-bordered">

    <tr>
      <td>
        s
      </td>
    </tr>
  </table>





</body>

</html>