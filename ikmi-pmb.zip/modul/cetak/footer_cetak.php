<div class="row divpadding">
  <div class="col-md-2 divborder divpadding2">
    <div class="">
      <center>
        <span class="huruf14"> 
          Tanggal Cetak: 
          <br><?php echo date("d M Y"); ?>
          <br><?php echo date("H:i:sa"); ?>
        </span>
      </center>
    </div>
  </div>
  <div class="col-md-8 divborder divpadding2">
    <div class="">
      <center>
        <span class="huruf14"> 
          Copyright: STMIK IKMI Cirobeon
          <br> - Modern Artificial Intelligence Campus - 
          <br><?=$tahun_angkatan ?>
        </span>
      </center>
    </div>
  </div>
  <div class="col-md-2 divborder divpadding2">
    <div class="">
      <center>
        <span class="huruf14">
          Diverifikasi oleh: 
          <br><?=$nama_petugas?>
        </span>
      </center>
    </div>
  </div>
</div>
