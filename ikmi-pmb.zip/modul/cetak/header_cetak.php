<div class="row divpadding">
  <div class="col-md-2 divborder">
    <div class="divpadding4">
      <center>
        <img class="img-fluid" src="assets/img/logos/ikmi120px.png">
      </center>
    </div>
  </div>
  <div class="col-md-8 divborder">
    <div class="divpadding4">
      <center>
        <img src="assets/img/logos/header_cetak.png" height="120px">
<!--         SEKOLAH TINGGI MANAJEMEN INFORMATIKA DAN KOMPUTER
        <h1 style="letter-spacing: 5px">STMIK IKMI CIREBON</h1>
        <p class="huruf14">
          Jalan Perjuangan No. 10B Majasem Kec Kesambi - Kota Cirebon Telp. (0231)490480 - 490481
        </p>
 -->      
      </center>
    </div>
  </div>
  <div class="col-md-2 divborder">
    <div class="divpadding4">
      <center>
        <?=$img_pas_photo?>
      </center>
    </div>
  </div>
  
</div>
