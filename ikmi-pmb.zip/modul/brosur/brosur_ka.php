<section id="brosur" class="pricing">
  <div class="container" data-aos="fade-up">

    <div class="row">
      <div class="col-md-6">



        <hr>
        <h1 style="color: red">On project...</h1>
        <p style="color: blue">be patient !!</p>


        
      </div>
    </div>

  </div>
</section><!-- End Pricing Section -->
