<section id="trainers" class="trainers">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Civitas</h2>
      <p>Civitas Akademika IKMI</p>
    </div>

    <div class="row" data-aos="zoom-in" data-aos-delay="100">
      <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
        <div class="member">
          <img src="assets/img/profile_na.gif" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Dr. Dadang Sudrajat, S.Si, M.Kom</h4>
            <span>Ketua STMIK IKMI</span>
            <p>
              -
            </p>
            <div class="social">
              <a href=""><i class="icofont-twitter" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-facebook" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-instagram" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-linkedin" onclick="return confirm('Fitur belum tersedia.')"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
        <div class="member">
          <img src="assets/img/profile_na.gif" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Bu Gita</h4>
            <span>Kaprodi Teknik Informatika</span>
            <p>
              -
            </p>
            <div class="social">
              <a href=""><i class="icofont-twitter" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-facebook" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-instagram" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-linkedin" onclick="return confirm('Fitur belum tersedia.')"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
        <div class="member">
          <img src="assets/img/profile_na.gif" class="img-fluid" alt="">
          <div class="member-content">
            <h4>Pa Odi</h4>
            <span>Kaprodi Manajemen Informatika</span>
            <p>
              -
            </p>
            <div class="social">
              <a href=""><i class="icofont-twitter" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-facebook" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-instagram" onclick="return confirm('Fitur belum tersedia.')"></i></a>
              <a href=""><i class="icofont-linkedin" onclick="return confirm('Fitur belum tersedia.')"></i></a>
            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Trainers Section -->
