<!-- ======= Counts Section ======= -->
<section id="counts" class="counts section-bg" style="display: none">
  <div class="container">

    <div class="row counters">

      <div class="col-lg-3 col-6 text-center">
        <span data-toggle="counter-up">6232</span>
        <p>Total Mahasiswa</p>
      </div>

      <div class="col-lg-3 col-6 text-center">
        <span data-toggle="counter-up">1564</span>
        <p>Mahasiswa Aktif</p>
      </div>

      <div class="col-lg-3 col-6 text-center">
        <span data-toggle="counter-up">4342</span>
        <p>Alumni</p>
      </div>

      <div class="col-lg-3 col-6 text-center">
        <span data-toggle="counter-up">115</span>
        <p>Jumlah Dosen</p>
      </div>

    </div>

  </div>
</section><!-- End Counts Section -->
