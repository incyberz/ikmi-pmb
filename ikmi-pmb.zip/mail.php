<?php 
mail("isholihin87@gmail.com", "subject", "message");

 ?>