halo.. anda nyasar ke folder uploads
