<!-- ======= About Section ======= -->
<section id="about" class="about">
  <div class="container" data-aos="fade-up">
    <div class="row">
    	<div class="col-md-4">
    		<img src="assets/img/not_exists.png" class="img-fluid">
    		<p style="margin-top: 15px; font-weight: bold">Wahh maaf, halaman yang Anda akses belum tersedia.</p><small><span style="color: darkblue">Broken-link-error has been saved.</span> | <?=$link_back?></small>
    		
    	</div>
    	
    </div>



  </div>
</section><!-- End About Section -->
