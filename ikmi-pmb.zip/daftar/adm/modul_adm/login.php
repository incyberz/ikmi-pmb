<h1>Link Login </h1>

<p>Silahkan Anda login via link login!</p>
<hr>
<p>Jika Anda belum mempunyai link, silahkan hubungi programmer!</p>