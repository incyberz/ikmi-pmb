<?php 
if(!isset($_SESSION)) session_start();

session_unset();



?>
<hr>
<p>
  <center>
    <a href="?">Relogin</a>
  </center>
</p>