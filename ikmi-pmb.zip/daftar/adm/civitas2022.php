<?php 
session_start();

$_SESSION['admpmb_email'] = "civitas@gmail.com";
$_SESSION['admpmb_id_petugas'] = 3;
$_SESSION['admpmb_nama_petugas'] = "Civitas Akademika";
$_SESSION['admpmb_admin_level'] = 1;
$_SESSION['admpmb_jabatan_petugas'] = "Civitas";


?>

<a href="index.php">Go to Dashboard</a>