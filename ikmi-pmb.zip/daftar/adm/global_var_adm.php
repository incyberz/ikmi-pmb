<?php 
$img_help = "<img src='../assets/img/icons/help.png' width='20px'>";
$img_check = "<img src='../assets/img/icons/check.png' width='20px'>";
$img_loading = "<img src='../assets/img/icons/loading6.gif' width='20px'>";
$img_warning = "<img src='../assets/img/icons/warning.png' width='20px'>";
$img_reject = "<img src='../assets/img/icons/reject.png' width='20px'>";
$img_un = "<img src='../assets/img/icons/un.png' width='20px'>";
$img_not_exist = "<img src='../assets/img/icons/not_exist.png' width='20px'>";

$img_wa = "<img src='../assets/img/icons/wa.png' width='25px'>";
$img_wa_unverified = "<img src='../assets/img/icons/wa_unverified.png' width='25px'>";
$img_wa_reject = "<img src='../assets/img/icons/wa_reject.png' width='25px'>";

$img_email = "<img src='../assets/img/icons/email.png' height='25px'>";
$img_email_unverified = "<img src='../assets/img/icons/email_unverified.png' height='25px'>";
$img_email_reject = "<img src='../assets/img/icons/email_reject.png' height='25px'>";
?>