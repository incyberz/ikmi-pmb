<?php 
session_start();

$_SESSION['admpmb_email'] = "bani@gmail.com";
$_SESSION['admpmb_id_petugas'] = 2;
$_SESSION['admpmb_nama_petugas'] = "Bani Nurhakim";
$_SESSION['admpmb_admin_level'] = 2;
$_SESSION['admpmb_jabatan_petugas'] = "Kabid FO";


?>

<a href="index.php">Go to Dashboard</a>