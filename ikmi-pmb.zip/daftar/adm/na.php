<div class="row">
  <div class="col-lg-12">
    <h3 class="page-header"><i class="fa fa-laptop"></i>Ooppss... something wrong with page!!</h3>
  </div>
</div>

<?php 
$a = $_SERVER['REQUEST_URI'];
?>

<ul>
	<li>Broken-Link: <i><?=$a?></i> has been saved at <?=date("Y-m-d H:i:s")?></li>
</ul>