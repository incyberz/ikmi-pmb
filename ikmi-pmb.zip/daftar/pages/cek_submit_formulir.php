<?php 
if($tanggal_submit_formulir=="")die("
  <div class='alert alert-danger'>
    Silahkan lengkapi Formulir terlebih dahulu untuk mengakses page ini.
    <hr>
    <a href='?formulir' class='btn btn-primary btn-sm'>Isi Formulir</a>
  </div>
  ");
?>