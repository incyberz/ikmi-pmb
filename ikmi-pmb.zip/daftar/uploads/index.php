<?php 
header("Location: ../");
?>