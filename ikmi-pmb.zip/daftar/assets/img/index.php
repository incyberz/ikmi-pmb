<?php 
header("Location: ../../");
?>